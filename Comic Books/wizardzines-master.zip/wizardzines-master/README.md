# wizardzines
sorted zines that collected from Julia Evans @b0rk twitter

You can find all zines at [wizardzines](https://wizardzines.com) and download most of them for free
But the recent 4 zines requires u to buy them. Luckily the author publish her commic draft on twitter. So I use a chrome extension called 'Twitter Media Downloader' to scrape her twitter media and then manully sort out the mess. 

Warning: some pages are not found from her twitter, if u would like to get the clean and printable full version of these zines, pls support Julia's work on [wizardzines](https://wizardzines.com)
